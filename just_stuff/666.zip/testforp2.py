#!/usr/bin/env python
import rospy
from quadrotor_msgs.msg import PositionCommand

def send_takeoff_command():
    rospy.init_node('send_takeoff_command')
    
    # 初始化发布者
    pub = rospy.Publisher('/position_cmd', PositionCommand, queue_size=10)
    rospy.sleep(1)  # 确保发布者已经注册

    # 创建并填充PositionCommand消息
    cmd = PositionCommand()
    cmd.header.stamp = rospy.Time.now()
    cmd.header.frame_id = "world"  # 确保这是无人机坐标系的正确名称
    cmd.position.x = 0.0  # 目标位置 X
    cmd.position.y = 0.0  # 目标位置 Y
    cmd.position.z = 0.3  # 目标高度，0.1m
    cmd.velocity.x = 0.0
    cmd.velocity.y = 0.0
    cmd.velocity.z = 0.0
    cmd.acceleration.x = 0.0
    cmd.acceleration.y = 0.0
    cmd.acceleration.z = 0.0
    cmd.yaw = 0.0
    cmd.yaw_dot = 0.0

    # 发布PositionCommand消息
    pub.publish(cmd)
    rospy.loginfo("Takeoff command to 0.1m published.")

if __name__ == '__main__':
    send_takeoff_command()
