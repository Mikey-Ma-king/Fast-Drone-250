#!/bin/bash
source devel/setup.bash

sh shfiles/takeoff.sh