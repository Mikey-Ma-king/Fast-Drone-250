#!/bin/bash
source devel/setup.bash
#python3 Initial_point.py
python3 testforp.py &

~/Fast-Perching/run_both.sh