#!/bin/bash
source devel/setup.bash
sh shfiles/rspx4.sh &

sleep 15

roslaunch px4ctrl run_ctrl.launch