#!/usr/bin/env python
import rospy
from geometry_msgs.msg import PoseStamped
from quadrotor_msgs.msg import PositionCommand
import numpy as np
import os

maxv = 4
maxa = 4

def limit_magnitude(vector, max_magnitude):
    magnitude = np.linalg.norm(vector)
    if magnitude > max_magnitude:
        return vector * (max_magnitude / magnitude)
    return vector

class PoseToPositionCommand:
    def __init__(self):
        # 读取无人机的实际坐标
        with open("average_position_info.txt", "r") as file:
            data = file.read().strip()
            # 解析文件中的坐标信息
            _, values = data.split(':')
            # 去掉非数字字符，并转换为浮点数
            x, y, z = [float(val.split('=')[1]) for val in values.split(',')]

        # 实际坐标
        self.real_position = np.array([x, y, z])

        # 初始化发布者和订阅者
        self.pub = rospy.Publisher('/position_cmd', PositionCommand, queue_size=30)
        self.sub = rospy.Subscriber('/drone0/odom_visualization/pose', PoseStamped, self.pose_callback)
        
        # 初始化用于计算速度和加速度的变量
        self.last_pose = None
        self.last_velocity = np.array([0.0, 0.0, 0.0])

        self.velocity_window = np.zeros((5, 3))  # 用于存储最近5个速度值
        self.acceleration_window = np.zeros((5, 3))  # 用于存储最近5个加速度值

        self.last_time = None
        self.message_received = False
        self.first_message_received = False  # 标记是否至少接收到过一次消息

        # 设置计时器以检查消息接收情况
        self.timer = rospy.Timer(rospy.Duration(0.3), self.check_message_received)

    def pose_callback(self, msg):
        self.message_received = True  # 标记已接收到消息
        if self.last_pose is not None:
            self.first_message_received = True  # 标记已至少接收到一次消息
        
        current_time = msg.header.stamp
        current_position = np.array([msg.pose.position.x, msg.pose.position.y, msg.pose.position.z])
        
        if self.last_time is not None and self.last_pose is not None:
            dt = (current_time - self.last_time).to_sec()
            if dt > 0:
                current_velocity = (current_position - self.last_pose) / (2*dt)
                acceleration = (current_velocity - self.last_velocity) / (30*dt) if dt > 0 else np.array([0.0, 0.0, 0.0])
                
                # 限制速度和加速度的大小
                current_velocity = limit_magnitude(current_velocity, maxv)
                acceleration = limit_magnitude(acceleration, maxa)
        
                # 更新窗口
                self.velocity_window = np.roll(self.velocity_window, -1, axis=0)
                self.velocity_window[-1] = current_velocity
                self.acceleration_window = np.roll(self.acceleration_window, -1, axis=0)
                self.acceleration_window[-1] = acceleration
                
                # 计算窗口平均
                current_velocity = np.mean(self.velocity_window, axis=0)
                acceleration = np.mean(self.acceleration_window, axis=0)

                # 创建并填充PositionCommand消息
                cmd = PositionCommand()
                cmd.header.stamp = current_time
                cmd.header.frame_id = msg.header.frame_id

                #更新current_position为实际坐标系下的值
                current_position[0] += self.real_position[0]
                current_position[1] += self.real_position[1]
                current_position[2] += self.real_position[2] - 2

                cmd.position.x, cmd.position.y, cmd.position.z = current_position
                cmd.velocity.x, cmd.velocity.y, cmd.velocity.z = current_velocity
                cmd.acceleration.x, cmd.acceleration.y, cmd.acceleration.z = acceleration
                cmd.yaw = 0.0
                cmd.yaw_dot = 0.0
                
                # 发布PositionCommand消息
                rospy.sleep(0.003)
                #print(self.last_pose)
                self.pub.publish(cmd)
                
                # 更新上次的状态
                self.last_velocity = current_velocity
                
        # 更新上次的位置和时间
        self.last_pose = current_position
        self.last_time = current_time

    def check_message_received(self, event):
        if not self.message_received and self.first_message_received:
            print(self.last_pose)
            rospy.loginfo("No pose updates for 1 second, initiating landing.")
            os.system('sh shfiles/land.sh')  # 执行降落命令
            rospy.signal_shutdown("Landing initiated.")  # 可选：关闭节点
        self.message_received = False  # 重置标志位

if __name__ == '__main__':
    rospy.init_node('pose_to_position_command_converter')
    converter = PoseToPositionCommand()
    rospy.spin()
