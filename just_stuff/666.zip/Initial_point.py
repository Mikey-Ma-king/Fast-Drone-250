#!/usr/bin/env python
# -*- coding: utf-8 -*-

import rospy
from quadrotor_msgs.msg import PositionCommand

# 存储接收到的位置信息
positions = []

# 回调函数，当接收到消息时被调用
def callback(data):
    global positions
    # 将位置数据添加到列表
    positions.append((data.position.x, data.position.y, data.position.z))
    
    # 当收集到三次数据后处理
    if len(positions) == 3:
        # 计算平均位置
        avg_x = sum(pos[0] for pos in positions) / 3
        avg_y = sum(pos[1] for pos in positions) / 3
        avg_z = sum(pos[2] for pos in positions) / 3
        
        # 构建要写入文件的字符串
        position_info = "Initial Position: x={:.3f}, y={:.3f}, z={:.3f}\n".format(avg_x, avg_y, avg_z)
        
        # 打开文件，并写入平均位置信息
        with open("average_position_info.txt", "w") as file:
            file.write(position_info)
        
        print(position_info)
        # 数据已足够，终止节点
        rospy.signal_shutdown("平均位置信息已记录")

# 初始化节点
rospy.init_node('average_position_listener', anonymous=True)

# 订阅/vins_fusion/imu_propagate话题，消息类型为PositionCommand
#rospy.Subscriber("/position_cmd", PositionCommand, callback)
rospy.Subscriber("/vins_fusion/imu_propagate", PositionCommand, callback)
# 让ROS节点持续运行直到被关闭
rospy.spin()
